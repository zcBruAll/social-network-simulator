import org.neo4j.driver.AuthTokens
import org.neo4j.driver.GraphDatabase

import sns.Simulator

def handler(query: Simulator.Query): Option[Int] =
  None

@main def Main =
  val s = Simulator(seed = 1337)
  for i <- 0 until 130 do println(s.randomEvent())

  val driver = GraphDatabase.driver(
    "neo4j://localhost:7687", AuthTokens.basic("neo4j", "beydb-beepr"))
  driver.verifyConnectivity()
  driver.close()